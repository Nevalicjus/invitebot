#!/bin/bash
screen -S invbot python3 bot.py
