<a target="https://invitebot.xyz/invite" href="https://invitebot.xyz/invite"><img src="https://invitebot.xyz/icons/bot-invite-blue.svg"></a>
<a href="https://discord.gg/96vwUWGddh"><img alt="Discord" src="https://img.shields.io/discord/788042409799712788?style=flat&logo=discord"></a>
<img src="https://invitebot.xyz/icons/license-MIT-yellow.svg">
<a target="https://docs.invitebot.xyz" href="https://docs.invitebot.xyz"><img src="https://invitebot.xyz/icons/read-the-docs-00BDD6.svg"></a>

# InviteBot
InviteBot is a simple discord.py bot that connects invites to roles, and adds them on_member_join

If you run into a bug please report it to me :)

## Usage
If you want to use the bot 'out of the box', I host it publically [here](https://invitebot.xyz/invite).</br>

## Selhosting
If you want to self-host the bot, see [the self-hosting documentation](https://docs.invitebot.xyz/self-host)

## Contributing
If you want to contribute, join the [Discord Support Server](https://invitebot.xyz/support) and see **§ Contributing** on #info📜.

## Contact
You can contact me on Discord - find me on the [Support Server](https://invitebot.xyz/support)/[Twitter](https://twitter.com/maciejbromirski)

## Thanks
Great thanks to Piotr Młynarski for the first version of the algorithm
